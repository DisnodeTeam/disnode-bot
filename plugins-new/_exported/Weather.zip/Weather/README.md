# Weather Plugin
---
## Commands

  * `[p]weather` - *The help of the plugin*
  * `[p]weather info` - *Rules of Casino*
  * `[p]weather forcast` - *General help for slots*

  ![Weather Plugin](http://i.imgur.com/ciMMYDj.gif)
---
## Creator Info
 **BY:** *Derek (Hazed SPaCE✘) at DisnodeTeam.*

 **Contact at: *Derek@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
