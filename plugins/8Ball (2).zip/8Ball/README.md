# 8-Ball Plugin
---
## Commands
  _[p] Is the bot's prefix_
  * `[p]8ball` - *Roll the 8-Ball (Can type a question after it if you desire.)*

---
## Creator Info
 **BY:** *Alex Carter (VictoryForPhil) at DisnodeTeam.*

 **Contact at: *Alex@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
