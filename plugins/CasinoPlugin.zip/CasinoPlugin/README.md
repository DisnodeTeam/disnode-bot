# Casino Plugin
---
  *  `[p] Stands for the bot prefix which varies from bot to bot example ! $ % & ^`
## Commands

  * `[p]casino` - *The help of the plugin*
  * `[p]casino rules` - *Rules of Casino*
  * `[p]casino slot` - *General help for slots*
  * `[p]casino wheel` - *General help for roulette*
  * `[p]casino flip` - *General help for coin flip*
  * `[p]casino crate` - *Crates that hold money and xp*
  * `[p]casino betters` - *See a list of recent betters*
  * `[p]casino time` - *Shows time left before income*
  * `[p]casino store` - *Store to buy money and xp*
  * `[p]casino jackpot` - *Shows Jackpot info*
  * `[p]casino transfer` - *Gives money to a user*
  * `[p]casino top` - *Leaderboard of top money holders*
  * `[p]casino lvtop` - *Leaderboard of top levels*
  * `[p]casino bal` - *Gets the bal of a user*
  * `[p]casino stats` - *Gets an users stats*

---
## Creator Info
 **BY:** *Garrett Nicholas (FireGamer3) at DisnodeTeam.*

 **Contact at: *Garrett@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
