# Minecraft Plugin
---
## Commands
  _[p] Is the bot's prefix_
  * `[p]mc skin <username>` - *Get the skin of a Minecraft user*

---
## Creator Info
 **BY:** *Alex Carter (VictoryForPhil) at DisnodeTeam.*

 **Contact at: *Alex@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
