# Sysinfo Plugin
---
  *  `[p] Stands for the bot prefix which varies from bot to bot example ! $ % & ^`
## Commands

  * `[p]sysinfo` - *CPU and RAM statics of the Bot Host*

---
## Creator Info
 **BY:** *Garrett Nicholas (FireGamer3) at DisnodeTeam.*

 **Contact at: *Garrett@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
