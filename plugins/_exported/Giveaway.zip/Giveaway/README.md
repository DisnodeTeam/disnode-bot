# Giveaway Plugin
---
  *  `[p] Stands for the bot prefix which varies from bot to bot example ! $ % & ^`
## Commands

  * `[p]giveaway` - *The help of the plugin*
  * `[p]giveaway new` - *Start a new Giveaway!*
  * `[p]giveaway disband` - *Cancels your current active Giveaway*
  * `[p]giveaway enter` - *Enter an active Giveaway*
  * `[p]giveaway draw` - *Draw a winner of your active Giveaway*

---
## Creator Info
 **BY:** *Garrett Nicholas (FireGamer3) at DisnodeTeam.*

 **Contact at: *Garrett@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
