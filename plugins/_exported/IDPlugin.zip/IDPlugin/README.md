# ID Plugin
---
## Usage

Command:

  * **roles** - *Get ID's of all roles in server* - `!id roles`

---
## Creator Info
 **BY:** *Alex Carter (VictoryForPhil) at DisnodeTeam.*

 **Contact at: *Alex@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)