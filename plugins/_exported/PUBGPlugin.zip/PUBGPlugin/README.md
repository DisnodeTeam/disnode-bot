# Pubg Plugin
---
  *  `[p] Stands for the bot prefix which varies from bot to bot example ! $ % & ^`
## Commands

  * `[p]pubg <PUBG player name> <solo|duo|squad (defaults to solo)>` - *Shows PUBG Stats for that player*

---
## Creator Info
 **BY:** *Alex Carter (VictoryForPhil) at DisnodeTeam.*

 **Contact at: *Alex@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
