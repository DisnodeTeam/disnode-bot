# Pubg Plugin
---
## Commands

  * `^roles add [role(s) names]` - *Adds roles to your user*
  * `^roles remove [role(s) names]` - *Removes roles to your user*
  * `^roles allow [role names]` - *Owner Only. Allow a role to be self-assigned on the guild.*
  * `^roles deny [role names]` - *Owner Only. Deny a role to be self-assigned on the guild. (Only for those that have been previously allowed.*


---
## Creator Info
 **BY:** *Alex Carter (VictoryForPhil) at DisnodeTeam.*

 **Contact at: *Alex@DisnodeTeam.com***

 **DISCORD** [Disnode Official Discord](https://discord.gg/AbZhCen)
